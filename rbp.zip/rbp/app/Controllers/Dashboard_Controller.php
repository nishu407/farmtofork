<?php
namespace App\Controllers;
class Dashboard_Controller extends BaseController
{
    public function index()
    {
        $data               = array();
        $data['body_html']  = view('Dashboard/dashboard_view',$data);
        $this->_main($data); 
    }

}