<?php
namespace App\Models;
use CodeIgniter\Model;
use CodeIgniter\Cache\CacheInterface;
class change_Model extends Model 
{
    protected function initialize()

    {
        $this->db_read                  = \Config\Database::connect();
        $this->db_write                 = \Config\Database::connect();
        $this->register                 = $this->db_write->table('register');
    }

    public function get_user_from_email($email)
    {
        $sql ="SELECT user_id,name,dob,gender,mobile_no,email,password,qualification,experience_time,language,salary_type,salary,category,job_position,social_network,address,photo
                FROM register 
        WHERE email = ?
        LIMIT 1"; 
        $query = $this->db_read->query($sql, [$email]);
        return $query->getRow();
    }
}