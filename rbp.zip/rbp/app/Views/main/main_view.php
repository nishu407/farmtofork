<?php echo $header_data; ?>
<?php echo $nawbar_data; ?>

<?php echo $body_html; ?>
<?php echo $footer_data; ?>