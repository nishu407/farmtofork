$(document).ready(function () 
{
  $(document).on('click','#resume_button',function()
  {
             //alert('hello');

   __user_resume_info();
  });

  $("#resume_form").validate(
  {
    ignore: "",
    onkeyup: false,
    onfocusout: false,
    rules: {
        
    },

    messages: { 

    },

    submitHandler: function (form, event) {
    event.preventDefault();
    __user_resume_info(form);
    }
  });

}); 

var __user_resume_info_xhr = null;
var __user_resume_info = function(form)
{

  $("#user_login #user_error").html("").hide();
  if( __user_resume_info_xhr != null )
  { 
    __user_resume_info_xhr.abort();
    __user_resume_info_xhr = null;
  }
     var photo              =$('#resume_form  #photo').val();
    var qualification          =$('#resume_form  #qualification').val();
  var academy_name               =$('#resume_form  #academy_name').val(); 
  var passing_year                =$('#resume_form  #passing_year').val();
  var edu_desp             =$('#resume_form #edu_desp').val();
  var company_name              =$('#resume_form  #company_name').val();
  var job_position                =$('#resume_form  #job_position').val();  
  var start_date         =$('#resume_form  #start_date').val();
  var end_date                =$('#resume_form  #end_date').val();
  var exp_desp             =$('#resume_form #exp_desp').val();

  if (photo=='')
   {
    $("#resume_form #user_error").html('Please enter Photo').show();
    return;
   }

  if( qualification == '' )
  {
    $("#resume_form #user_error").html( 'Please enter Qualification.' ).show();
    return;
  }
  if(academy_name == '' )
  {
    $("#resume_form #user_error").html( 'Please enter academy_name.' ).show();
    return;
  }
  if(passing_year == '')
  {
    $("#resume_form #user_error").html( 'Please enter passing_year.').show();
    return;
  }
   if (edu_desp=='')
   {
    $("#resume_form #user_error").html('Please select edu_desp').show();
    return;
   }

  if( company_name == '' )
  {
    $("#resume_form #user_error").html( 'Please enter company_name.' ).show();
    return;
  }
  if( job_position == '' )
  {
    $("#resume_form #user_error").html( 'Please enter job_position.' ).show();
    return;
  }
  
  if(start_date == '' )
  {
    $("#resume_form #user_error").html( 'Please enter start_date.' ).show();
    return;
  }

  if( end_date == '' )
  {
    $("#resume_form #user_error").html( 'Please enter end_date.' ).show();
    return;
  }
  
if (exp_desp=='')
   {
    $("#resume_form #user_error").html('Please enter exp_desp').show();
    return;
   }
  
   
  __user_resume_info_form_xhr = $.ajax(
  {
    type: "POST"
    ,url: baseUrl + "/resume"
    , data: {'photo' :photo,'qualification' :qualification,'academy_name':academy_name,'passing_year':passing_year,'edu_desp':edu_desp,'company_name':company_name,'job_position' :job_position,'start_date' :start_date,'end_date' :end_date,'exp_desp' :exp_desp}
    , dataType: 'json'
    , error: function () {
    },

    success: function(response) 
    {
      if (typeof response.error !== 'undefined' && response.error !== '') 
      {
        console.log("An error occurred: " + response.error);
      } 
      else 
      {

        console.log('resume successful.');
        window.location.href = baseUrl +"dashboard";
      }
    }
  }); 
} 


