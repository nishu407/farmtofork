<?php
namespace App\Models;
use CodeIgniter\Model;
use CodeIgniter\Cache\CacheInterface;
class register_model extends Model 
{
	protected function initialize()

    {
        $this->db_read 	                = \Config\Database::connect();
        $this->db_write                 = \Config\Database::connect();
        $this->instructor_login     = $this->db_write->table('instructor_login');
    }

    public function add_student($data)
    {
        $this->instructor_login->insert($data);
        return $this->db_write->insertID();
    }

    public function is_email_exist( $email, $user_id = NULL )
    {
        $cond = '';
        if( $user_id !='' && $user_id != 0 )
        {
            $cond = ' AND user_id != '.$user_id;
        }
         
        $sql = "SELECT email 
                FROM   instructor_login
                WHERE email = ? 
                $cond ";
        $query = $this->db_read->query( $sql, array( $email ) );
        return $query->getNumRows();
    }
}