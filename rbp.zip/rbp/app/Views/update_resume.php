<!DOCTYPE html>

	<body>
		<div class="pre-loader">
			<div class="pre-loader-box">
				<div class="loader-logo">
					<img src="<?=base_url()?>asset/vendors/images/logo.png" alt="" />
				</div>
				<div class="loader-progress" id="progress_div">
					<div class="bar" id="bar1"></div>
				</div>
				<div class="percent" id="percent1">0%</div>
				<div class="loading-text">Loading...</div>
			</div>
		</div>

		<div class="mobile-menu-overlay"></div>

		<div class="main-container">
			<div class="pd-ltr-20 xs-pd-20-10">
				<div class="min-height-200px">
					<div class="page-header">
						<div class="row">
							<div class="col-md-6 col-sm-12">
								<div class="title">
									<h4>MY RESUME</h4>
								</div>
								<nav aria-label="breadcrumb" role="navigation">
									<ol class="breadcrumb">
										<li class="breadcrumb-item">
											<a href="index.html">Home</a>
										</li>
										<li class="breadcrumb-item active" aria-current="page">
											RESUME
										</li>
									</ol>
								</nav>
							</div>
							<div class="col-md-6 col-sm-12 text-right">
								<div class="dropdown">
									<a
										class="btn btn-secondary dropdown-toggle"
										href="#"
										role="button"
										data-toggle="dropdown"
									>
										January 2018
									</a>
									<div class="dropdown-menu dropdown-menu-right">
										<a class="dropdown-item" href="#">Export List</a>
										<a class="dropdown-item" href="#">Policies</a>
										<a class="dropdown-item" href="#">View Assets</a>
									</div>
								</div>
							</div>
						</div>
					</div>
					<!-- Default Basic Forms Start -->
					<div class="pd-20 card-box mb-30">
						<div class="clearfix">
							<div class="pull-left">
								<!-- <h4 class="text-blue h4">Resume</h4> -->
								<!-- <p class="mb-30">All bootstrap element classies</p> -->
							</div>
							<!-- <div class="pull-right">
								<a
									href="#basic-form1"
									class="btn btn-primary btn-sm scroll-click"
									rel="content-y"
									data-toggle="collapse"
									role="button"
									><i class="fa fa-code"></i> Source Code</a
								>
							</div> -->
<form id="resume_form" class="resume_form" action="javascript:void(0)" method="post">
	    <h4>CV Attachment</h4>

<div class="form-row">
<div class="form-group col-md-6">
      <label for="skill_occupation"><b>Attach CV</b></label>
      <input type="file" class="form-control" id="photo" name="photo">
    </div> </div>
    	    <h4>Education</h4>
<div class="form-row">
<div class="form-group col-md-6">
    <label for="mobile"><b>Qualification</b></label>
      <input type="text" class="form-control" id="qualification" name="qualification" placeholder="Enter Your Qualification." value="<?php echo $user_data->qualification;?>">
  </div> 
  <div class="form-group col-md-6">
	  <label for="mobile"><b>Academy</b></label>
      <input type="text" class="form-control" id="academy_name" name="academy_name" placeholder="Enter Your Academy Position." value="<?php echo $user_data->Academy;?>">
       </div> 
  
   </div>
  <div class="form-row">
  	<div class="form-group col-md-6">
    <label for="mobile"><b>Year</b></label>
      <input type="text" class="form-control" id="year" name="year" placeholder="Enter Your job Position." value="<?php echo $user_data->year;?>">
  </div> 
<div class="form-group col-md-6">
      <label for="skill_occupation"><b>Description</b></label>
		<textarea class="form-control" name="edu_desp" id="edu_desp" placeholder="Enter Your Description"></textarea>
    </div> 
    
   </div>
  <div class="form-row">

    
   </div>
   <h4>Experience</h4>
   <div class="form-row">
 <div class="form-group col-md-6">
   <label for="mobile"><b>Company Name</b></label>
     <input type="text" class="form-control" id="company_name" name="company_name" placeholder="Enter Your job Position." value="<?php echo $user_data->job_title;?>">
  </div> 
  <div class="form-group col-md-6">
    <label for="mobile"><b>Job Position</b></label>
     <input type="text" class="form-control" id="job_position" name="job_position" placeholder="Enter Your job Position." value="<?php echo $user_data->job_position;?>">
  </div></div>
  	<div class="form-group row">
<div class="form-group col-md-6">
    <label for="mobile"><b> Start Date</b></label>
<input class="form-control date-picker" placeholder="Select Date" type="text" name="start_date" id="start_date">
		</div>
		<div class="form-group col-md-6">
  <label for="mobile"><b> End Date</b></label>
<input class="form-control date-picker" placeholder="Select Date" type="text" name="end_date" id="end_date">
		</div></div>
   <div class="form-row">
<div class="form-group col-md-6">
      <label for="skill_occupation"><b>Description</b></label>
		<textarea class="form-control" name="exp_desp" id="exp_desp" placeholder="Enter Your Description"></textarea>
    </div> 
   <div class="checkbox" >
      <label><input type="checkbox">Accept Term and Condition.</label>
    </div></div>
   
        <button class="btn btn-danger btn-lg" name="resume_button" id="resume_button">submit</button>
       <!-- <button class="btn btn-primary btn-lg " name="edit" id="edit">Edit</button> -->
</div></div>
    <div id="user_error" class="text-danger" role="alert" style="display:none;"></div>      
      </form>
						</div>

				
			
			</div>
		</div>
		<!-- welcome modal start -->
		
		<!-- welcome modal end -->
		<!-- js -->
		<script src="vendors/scripts/core.js"></script>
		<script src="vendors/scripts/script.min.js"></script>
		<script src="vendors/scripts/process.js"></script>
		<script src="vendors/scripts/layout-settings.js"></script>
		<!-- Google Tag Manager (noscript) -->
		<noscript
			><iframe
				src="https://www.googletagmanager.com/ns.html?id=GTM-NXZMQSS"
				height="0"
				width="0"
				style="display: none; visibility: hidden"
			></iframe
		></noscript>
		<!-- End Google Tag Manager (noscript) -->
		<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>var baseUrl = '<?php echo base_url();?>';</script>
	<script type="text/javascript" src="<?php echo base_url()?>asset/src/scripts/resume.js"></script>

	</body>
</html>
