<?php
namespace App\Controllers;
class Shortlist_Controller extends BaseController
{
   public function __construct()
   {
      $this->request            = \Config\Services::request();
      $this->uri                = new \CodeIgniter\HTTP\URI();
      $this->session            = \Config\Services::session();
      $this->shortlist_model       = model('shortlist_model');
      $this->user_id            = $this->session->get('user_id');
   }

 public function index()
   {
      $user_id            =$this->user_id;
      $data['user_data']     = $this->shortlist_model-> user_id_exist($user_id);

        $data['body_html']  = view('shortlist',$data);
        $this->_main($data); 
   }



    public function details()
   {
      $company_name      = $this->request->getPost('company_name');
     $job_position      = $this->request->getPost('job_position');
     $start_date          = $this->request->getPost('start_date');
     $location            = $this->request->getPost('location');
     
    $data = 
      [
         
        'company_name'  => $company_name,
         'job_position'   => $job_position ,
        'start_date'      => $start_date ,
        'location'        => $location ,
        
      ];
             $this->shortlist_model->add($data);
            echo json_encode(["success" => true]);
      
    }
}
