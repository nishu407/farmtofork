<?php
namespace App\Controllers;
class Apply_Controller extends BaseController
{
   public function __construct()
   {
      $this->request            = \Config\Services::request();
      $this->uri                = new \CodeIgniter\HTTP\URI();
      $this->session            = \Config\Services::session();
      $this->apply_model       = model('apply_model');
      $this->user_id            = $this->session->get('user_id');
   }

 public function index()
   {
      $user_id            =$this->user_id;
      $data['user_data']     = $this->apply_model-> user_id_exist($user_id);
      $data['body_html']  = view('apply',$data);
      $this->_main($data); 
   }

public function approve($user_id)
    {
        $apply_model = new apply_model();
        if ($apply_model->updateStatus($user_id, 'approved')) {
            return $this->response->setJSON(['status' => 'success', 'message' => 'Post approved']);
        }
        return $this->response->setJSON(['status' => 'error', 'message' => 'Failed to approve post']);
    }

    public function disapprove($user_id)
    {
        $apply_model = new apply_model();
        if ($apply_model->updateStatus($user_id, 'disapproved')) {
            return $this->response->setJSON(['status' => 'success', 'message' => 'Post disapproved']);
        }
        return $this->response->setJSON(['status' => 'error', 'message' => 'Failed to disapprove post']);
    }
}
    

