<?php

namespace App\Controllers;

class Front_Controller extends BaseController
{
    public function index()
    {
        return view('front_end_view');
    }
}
