$(document).ready(function () 
{
  $(document).on('click','#profile_button',function()
 {
                    // alert('hello');

    __user_profile_info();
  });

}); 

var __user_profile_info_xhr = null;
var __user_profile_info = function(form)
{

  $("#user_login #user_error").html("").hide();
  if( __user_profile_info_xhr != null )
  { 
    __user_profile_info_xhr.abort();
    __user_profile_info_xhr = null;
  }

  var user_id                 =$('#profile_form  #my_profile_edit').val();
  var name       =$('#profile_form  #name').val();
  var mobile_no                  =$('#profile_form  #mobile_no').val();
  var qualification        =$('#profile_form  #qualification').val();
   var email                   =$('#profile_form  #email').val();
     var photo                   =$('#profile_form  #photo').val();
    var dob               =$('#profile_form  #dob').val(); 
    var gender                =$('#profile_form  #gender').val();
    var experience_time               =$('#profile_form  #experience_time').val();
    var language       =$('#profile_form  #language').val();
  var salary_type               =$('#profile_form  #salary_type').val(); 
  var salary                =$('#profile_form  #salary').val();
  var category                   =$('#profile_form  #category').val();
  var job_position                  =$('#profile_form  #job_position').val();
  var social_network        =$('#profile_form  #social_network').val();

  if( name == '' )
  {
    $("#profile_form #user_error").html( 'Please enter full name.' ).show();
    return;
  }
  if( dob == '' )
  {
    $("#profile_form #user_error").html( 'Please enter date of birth.' ).show();
    return;
  }

  if( gender == '' )
  {
    $("#profile_form #user_error").html( 'Please choose your gender.' ).show();
    return;
  }

  if( email == '' )
  {
    $("#profile_form #user_error").html( 'Please enter email.' ).show();
    return;
  }
 
  if( mobile_no == '' )
  {
    $("#profile_form #user_error").html( 'Please enter mobile_no.' ).show();
    return;
  }
  if( qualification == '' )
  {
    $("#profile_form #user_error").html( 'Please enter your qualification.' ).show();
    return;
  }
  if( experience_time == '' )
  {
    $("#profile_form #user_error").html( 'Please enter experience_time.' ).show();
    return;
  }

if( photo == '' )
  {
    $("#profile_form #user_error").html( 'Please enter photo.' ).show();
    return;
  }

if( language == '' )
  {
    $("#profile_form #user_error").html( 'Please choose your language.' ).show();
    return;
  }
 if( salary_type == '' )
  {
    $("#profile_form #user_error").html( 'Please choose your salary_type.' ).show();
    return;
  }
if( salary == '' )
  {
    $("#profile_form #user_error").html( 'Please enter your salary.' ).show();
    return;
  }
  if( category == '' )
  {
    $("#profile_form #user_error").html( 'Please choose your field.' ).show();
    return;
  }
  if( job_position == '' )
  {
    $("#profile_form #user_error").html( 'Please enter your job_position.' ).show();
    return;
  }
  if( social_network == '' )
  {
    $("#profile_form #user_error").html( 'Please enter your social_network.' ).show();
    return;
  }
  __user_profile_info_form_xhr = $.ajax(
  {
    type: "POST"
    ,url: baseUrl + "profile"
    , data: {'user_id':user_id,'name':name,'dob':dob,'gender':gender,'email':email,'mobile_no':mobile_no,'qualification':qualification,'experience_time':experience_time,'language':language,'photo':photo,'category':category,'salary':salary,'salary_type':salary_type,'job_position':job_position,'social_network':social_network}
    , dataType: 'json'
    , error: function () {
    },

    success: function(response) 
    {           
      if (typeof response.error !== 'undefined' && response.error !== '') 
      {
        console.log("An error occurred: " + response.error);
      } 
      else 
      {
        console.log('Update successful.');
        window.location.href = baseUrl +"profile";
      }
    }
  }); 
}