$(document).ready(function () 
{
  $(document).on('click','#register_button',function()
  {
   //alert('hello');
    __user_registration_info();
  });

  $("#register_form").validate(
  {
    ignore: "",
    onkeyup: false,
    onfocusout: false,
    rules: {
        
    },

    messages: { 

    },

    submitHandler: function (form, event) {
    event.preventDefault();
    __user_registration_info(form);
    }
  });

}); 

var __user_registration_info_xhr = null;
var __user_registration_info = function(form)
{

  $("#user_login #user_error").html("").hide();
  if( __user_registration_info_xhr != null )
  { 
    __user_registration_info_xhr.abort();
    __user_registration_info_xhr = null;
  }

  var registration_date       =$('#register_form  #registration_date').val(); 
  var firstname               =$('#register_form  #firstname').val(); 
  var lastname                =$('#register_form  #lastname').val();
  var email                   =$('#register_form  #email').val();
  var password                =$('#register_form  #password').val();  
  var confirmpassword         =$('#register_form  #confirmpassword').val();
  var mobile                  =$('#register_form  #mobile').val();
  var skill_occupation        =$('#register_form  #skill_occupation').val();
  var biography               =$('#register_form  #biography').val();

  if( registration_date == '' )
  {
    $("#register_form #user_error").html( 'Please enter registration date.' ).show();
    return;
  }
  if( firstname == '' )
  {
    $("#register_form #user_error").html( 'Please enter first name.' ).show();
    return;
  }

  if( lastname == '' )
  {
    $("#register_form #user_error").html( 'Please enter last name.' ).show();
    return;
  }
  
  if( email == '' )
  {
    $("#register_form #user_error").html( 'Please enter email.' ).show();
    return;
  }

  if( password == '' )
  {
    $("#register_form #user_error").html( 'Please enter the password.' ).show();
    return;
  }

  if(confirmpassword == '' )
  {
    $("#register_form #user_error").html( 'Please enter confirmpassword.' ).show();
    return;
  }

  if( mobile == '' )
  {
    $("#register_form #user_error").html( 'Please enter mobile.' ).show();
    return;
  }
  if( skill_occupation == '' )
  {
    $("#register_form #user_error").html( 'Please enter skill occupation.' ).show();
    return;
  }
  if( biography == '' )
  {
    $("#register_form #user_error").html( 'Please enter biography.' ).show();
    return;
  }

  __user_registration_info_form_xhr = $.ajax(
  {
    type: "POST"
    ,url: baseUrl + "sign_up/sign_up"
    , data: {'registration_date' :registration_date,'firstname' :firstname,'lastname' :lastname,'email' :email,'password' :password,'confirmpassword' :confirmpassword,'mobile': mobile,'skill_occupation' :skill_occupation,'biography' :biography}
    , dataType: 'json'
    , error: function () {
    },

    success: function(response) 
    {
      if (typeof response.error !== 'undefined' && response.error !== '') 
      {
        console.log("An error occurred: " + response.error);
      } 
      else 
      {
        console.log('Login successful.');
        window.location.href = baseUrl +"login";
      }
    }
  }); 
} 


