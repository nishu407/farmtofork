<div class="footer-wrap pd-20 mb-20 card-box">
    DeskApp - Bootstrap 4 Admin Template By
    <a href="https://github.com/dropways" target="_blank"
        >Ankit Hingarajiya</a
    >
</div>

<script src="<?=base_url()?>asset/vendors/scripts/core.js"></script>
<script src="<?=base_url()?>asset/vendors/scripts/script.min.js"></script>
<script src="<?=base_url()?>asset/vendors/scripts/process.js"></script>
<script src="<?=base_url()?>asset/vendors/scripts/layout-settings.js"></script>
<script src="<?=base_url()?>asset/src/plugins/apexcharts/apexcharts.min.js"></script>
<script src="<?=base_url()?>asset/src/plugins/datatables/js/jquery.dataTables.min.js"></script>
<script src="<?=base_url()?>asset/src/plugins/datatables/js/dataTables.bootstrap4.min.js"></script>
<script src="<?=base_url()?>asset/src/plugins/datatables/js/dataTables.responsive.min.js"></script>
<script src="<?=base_url()?>asset/src/plugins/datatables/js/responsive.bootstrap4.min.js"></script>
<script src="<?=base_url()?>asset/vendors/scripts/dashboard.js"></script>