<!DOCTYPE html>

	<body>
		<div class="pre-loader">
			<div class="pre-loader-box">
				<div class="loader-logo">
					<img src="vendors/images/logo.png" alt="" />
				</div>
				<div class="loader-progress" id="progress_div">
					<div class="bar" id="bar1"></div>
				</div>
				<div class="percent" id="percent1">0%</div>
				<div class="loading-text">Loading...</div>
			</div>
		</div>

		<div class="mobile-menu-overlay"></div>

		<div class="main-container">
			<div class="pd-ltr-20 xs-pd-20-10">
				<div class="min-height-200px">
					<div class="page-header">
						<div class="row">
							<div class="col-md-6 col-sm-12">
								<div class="title">
									<h4>Profile</h4>
								</div>
								<nav aria-label="breadcrumb" role="navigation">
									<ol class="breadcrumb">
										<li class="breadcrumb-item">
											<a href="index.html">Home</a>
										</li>
										<li class="breadcrumb-item active" aria-current="page">
											Profile
										</li>
									</ol>
								</nav>
							</div>
							<div class="col-md-6 col-sm-12 text-right">
								<div class="dropdown">
									<a
										class="btn btn-secondary dropdown-toggle"
										href="#"
										role="button"
										data-toggle="dropdown"
									>
										January 2018
									</a>
									<div class="dropdown-menu dropdown-menu-right">
										<a class="dropdown-item" href="#">Export List</a>
										<a class="dropdown-item" href="#">Policies</a>
										<a class="dropdown-item" href="#">View Assets</a>
									</div>
								</div>
							</div>
						</div>
					</div>
					<!-- Default Basic Forms Start -->
					<div class="pd-20 card-box mb-30">
						<div class="clearfix">
							<div class="pull-left">
								<h4 class="text-blue h4">PROFILE</h4>
								<!-- <p class="mb-30">All bootstrap element classies</p> -->
							</div>
							<!-- <div class="pull-right">
								<a
									href="#basic-form1"
									class="btn btn-primary btn-sm scroll-click"
									rel="content-y"
									data-toggle="collapse"
									role="button"
									><i class="fa fa-code"></i> Source Code</a
								>
							</div> -->
						</div>
<form id="adduser" class="adduser" action="javascript:void(0)" method="post">
<div class="form-row">
<div class="form-group col-md-6">
 <label for="inputAddress"><b>Full Name</b></label>
    <input type="text" class="form-control" id="name" name="can_name" value="<?php echo $user_data->name; ?>">
  </div>
  <div class="form-group col-md-6">
    <label for="inputdate"><b>DOB</b></label>
      <input type="date" class="form-control" id="dob" name="dob" placeholder="Enter date of birth." value="<?php echo $user_data->dob;?>">
  </div></div>
    <div class="form-row">
<div class="form-group col-md-6 ">
  <label for="biography"><b>Gender</b></label>
<label class="check"><input type="radio" class="iradio" name="gender" id="gender" value="Male"/>Male</label>
 <label class="check"><input type="radio" class="iradio" name="gender" id="gender" value="Female" />Female</label></div>
    <div class="form-group col-md-6">
      <label for="inputnumber"><b>Mobile No</b></label>
      <input type="mobile" class="form-control" id="mobile_no" name="mobile_no" placeholder="Enter Mobile No." value="<?php echo $user_data->mobile_no;?>">
    </div></div>
    <div class="form-row">
   <div class="form-group col-md-6">
    <label for="email"><b>Email</b></label>
      <input type="email" class="form-control" id="email" name="email" placeholder="Enter Email" value="<?php echo $user_data->email;?>">
  </div> 
    <div class="form-group col-md-6">
      <label for="inputPassword4"><b>Qualification</b></label>
      <input type="text" class="form-control" id="Qualification" name="Qualification" placeholder="Enter Qualification" value="<?php echo $user_data->Qualification;?>">
    </div>
  </div>
  <div class="form-row">
  <div class="form-group col-md-6">
    <label for="mobile"><b>EXPERIENCE TIME</b></label>
      <input type="text" class="form-control" id="experience_time" name="experience_time" placeholder="Enter EXPERIENCE TIME." value="<?php echo $user_data->experience_time;?>">
  </div>
   <div class="form-group col-md-6">
    <label for="mobile"><b>Language</b></label>
     
      <select class="custom-select2 form-control" multiple="multiple" id="language" name="language" placeholder="Enter Language."style="width: 100%">
    <optgroup label="">
	
	<option value="<?php echo $user_data->language;?>">Marathi</option>
	<option value="<?php echo $user_data->language;?>">Hindi</option>
	<option value="<?php echo $user_data->language;?>">English</option>
	<option value="<?php echo $user_data->language;?>">Other</option>
</optgroup></select>
  </div>  
   </div>

   <div class="form-row">
  <div class="form-group col-md-6">
    <label for="mobile"><b>Salary type</b></label>
    <select class="custom-select2 form-control"name="salary_type" id="salary_type"  style="width: 100%; height: 38px" placeholder="Enter salary type.">
<optgroup label="">
<option value="<?php echo $user_data->salary_type;?>">Monthly</option>
<option value="<?php echo $user_data->salary_type;?>">Weekly</option>
<option value="<?php echo $user_data->salary_type;?>">Daily</option>
<option value="<?php echo $user_data->salary_type;?>">Hourly</option>
<option value="<?php echo $user_data->salary_type;?>">Yearly</option>
</optgroup>
</select>									
  </div>
   <div class="form-group col-md-6">
    <label for="mobile"><b>Salary</b></label>
      <input type="text" class="form-control" id="salary" name="salary" placeholder="Enter Salary." value="<?php echo $user_data->salary;?>">
  </div>  
   </div>
   <div class="form-row">
  <div class="form-group col-md-6">
    <label for="mobile"><b>Category</b></label>
    <select class="custom-select2 form-control" multiple="multiple" id="category" name="category" placeholder="Enter Category."style="width: 100%">
    <optgroup label="">
	<option value="<?php echo $user_data->category;?>">Advertising</option>
	<option value="<?php echo $user_data->category;?>">Hawaii</option>

	<option value="<?php echo $user_data->category;?>">California</option>
	<option value="<?php echo $user_data->category;?>">Nevada</option>
	<option value="<?php echo $user_data->category;?>">Oregon</option>
	<option value="<?php echo $user_data->category;?>">Washington</option>
</optgroup></select>
  </div>
   <div class="form-group col-md-6">
    <label for="mobile"><b>Job Title</b></label>
      <input type="text" class="form-control" id="job_position" name="job_position" placeholder="Enter Your job Position." value="<?php //echo $user_data->job_title;?>">
  </div>  
   </div>
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="skill_occupation"><b>Photo</b></label>
      <input type="file" class="form-control" id="photo" name="photo" value="<?php echo $user_data->photo;?>">
    </div>
 <div class="form-group col-md-6">
      <label for="inputAddress"><b>Address</b></label>
      <input type="text" class="form-control" id="address" name="address" placeholder="Enter address" value="<?php echo $user_data->address;?>">
    </div></div>
   
<!-- <input type="hidden" name="my_profile_edit" id="my_profile_edit" value="<?php //echo $user_data->//user_id; ?>">  -->
							<a class="btn btn-primary btn-block btn-signin" name="profile_button" id="profile_button" href="<?php echo base_url();?>profile">Update</a>
         
      </form>
						<div class="collapse collapse-box" id="basic-form1">
							<div class="code-box">
								<div class="clearfix">
									<a
										href="javascript:;"
										class="btn btn-primary btn-sm code-copy pull-left"
										data-clipboard-target="#copy-pre"
										><i class="fa fa-clipboard"></i> Copy Code</a
									>
									<a
										href="#basic-form1"
										class="btn btn-primary btn-sm pull-right"
										rel="content-y"
										data-toggle="collapse"
										role="button"
										><i class="fa fa-eye-slash"></i> Hide Code</a
									>
								</div>
								<pre><code class="xml copy-pre" id="copy-pre">

							</code></pre>
							</div>
						</div>
					</div>
					
</code></pre>
							</div>
						</div>
					</div>
					
			
			</div>
		</div>
		<!-- welcome modal start -->
		
		<!-- welcome modal end -->
		<!-- js -->
		<script src="vendors/scripts/core.js"></script>
		<script src="vendors/scripts/script.min.js"></script>
		<script src="vendors/scripts/process.js"></script>
		<script src="vendors/scripts/layout-settings.js"></script>
		<!-- Google Tag Manager (noscript) -->
		<noscript
			><iframe
				src="https://www.googletagmanager.com/ns.html?id=GTM-NXZMQSS"
				height="0"
				width="0"
				style="display: none; visibility: hidden"
			></iframe
		></noscript>
		<!-- End Google Tag Manager (noscript) -->
		<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>var baseUrl = '<?php echo base_url();?>';</script>
	<script type="text/javascript" src="<?php echo base_url()?>asset/src/scripts/update_profile.js"></script>

	</body>
</html>
