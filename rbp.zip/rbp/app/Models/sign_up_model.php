<?php
namespace App\Models;
use CodeIgniter\Model;
use CodeIgniter\Cache\CacheInterface;
class sign_up_model extends Model 
{
    protected function initialize()

    {
        $this->db_read                  = \Config\Database::connect();
        $this->db_write                 = \Config\Database::connect();
        $this->register                     = $this->db_write->table('register');
    }
    public function add($data)
    {
        $this->register->insert($data);
        return $this->db_write->insertID();
    }

    public function is_email_exist(  $email, $user_id = NULL )
    {
        $cond = '';
        if( $user_id !='' && $user_id != 0 )
        {
            $cond = ' AND user_id != '.$user_id;
        }
        
        $sql = "SELECT email 
                FROM register
                WHERE email = ? 
                $cond ";
        $query = $this->db_read->query( $sql, array( $email ) );
        return $query->getNumRows();
    }

    }

    
    
