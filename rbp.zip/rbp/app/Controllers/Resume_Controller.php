<?php
namespace App\Controllers;
class Resume_Controller extends BaseController
{
   public function __construct()
   {
      $this->request            = \Config\Services::request();
      $this->uri                = new \CodeIgniter\HTTP\URI();
      $this->session            = \Config\Services::session();
      $this->resume_model       = model('resume_model');
      $this->resume_id            = $this->session->get('resume_id');
   }

 public function index()
   {
        $data               = array();
        $data['body_html']  = view('resume',$data);
        $this->_main($data); 
   }


    public function resume()
   {
           $photo              = $this->request->getPost('photo');
      $qualification              = $this->request->getPost('qualification');
      $academy_name       = $this->request->getPost('academy_name');
      $passing_year       = $this->request->getPost('passing_year');
      $edu_desp          = $this->request->getPost('edu_desp');
     $company_name      = $this->request->getPost('company_name');
     $job_position      = $this->request->getPost('job_position');
     $start_date          = $this->request->getPost('start_date');
     $end_date            = $this->request->getPost('end_date');
     $exp_desp            = $this->request->getPost('exp_desp');
     
    $data = 
      [
         'photo'           => $photo ,
         'qualification'      => $qualification,
         'academy_name'   => $academy_name,
         'passing_year'   => $passing_year,
         'edu_desp'       => $edu_desp,
        'company_name'  => $company_name,
         'job_position'   => $job_position ,
        'start_date'      => $start_date ,
        'end_date'        => $end_date ,
        'exp_desp'        => $exp_desp ,
        
      ];
             $this->resume_model->add($data);
            echo json_encode(["success" => true]);
      
    }

public function resume_view()
   {
            $resume_id         =$this->resume_id;
        $data['user_data']     = $this->resume_model->resume_id_exist($resume_id);
        $data['body_html']  = view('resume_pdf',$data);
        $this->_main($data); 
   }
}