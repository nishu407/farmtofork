<?php
namespace App\Controllers;
class Signup_Controller extends BaseController
{
   public function __construct()
   {
      $this->request            = \Config\Services::request();
      $this->uri                = new \CodeIgniter\HTTP\URI();
      $this->session            = \Config\Services::session();
      $this->sign_up_model       = model('sign_up_model');
      $this->user_id            = $this->session->get('user_id');
   }


    public function index()
    {
        $data               = array();
          return view('sign_up',$data);
        
    }
public function sign_up()
   {
      $name               = $this->request->getPost('name');
      $address               = $this->request->getPost('address');
      $dob                 = $this->request->getPost('dob');
      $gender                 = $this->request->getPost('gender');
      $mobile_no              = $this->request->getPost('mobile_no');
      $email                    = $this->request->getPost('email');
      $password                 = password_hash( $this->request->getPost('password'), PASSWORD_DEFAULT );
      $confirmpassword          = $this->request->getPost('confirmpassword');
      $qualification              = $this->request->getPost('qualification');
      $experience_time                 = $this->request->getPost('experience_time');
       $language               = $this->request->getPost('language');
       $photo                 = $this->request->getPost('photo');
       $salary_type               = $this->request->getPost('salary_type');
       $salary                 = $this->request->getPost('salary');
       $category                 = $this->request->getPost('category');
       $job_position                 = $this->request->getPost('job_position');


      $data = 
      [
         'name'           => $name,
         'address'           => $address,
         'dob'                => $dob,
         'gender'             => $gender,
         'mobile_no'          => $mobile_no,
         'email'              => $email,
         'password'           => $password,
         'qualification'      => $qualification,
         'experience_time'    => $experience_time,
         'language'             => $language,
         'photo'              => $photo,
         'salary_type'    => $salary_type,
         'salary'             => $salary,
         'category'              => $category,
         'job_position'              => $job_position,



      ];

         $is_email_exist = $this->sign_up_model->is_email_exist( $email,  $this->user_id );
         if( $is_email_exist )
         {
            echo json_encode( array( "error" => 'This email is already registered' ) );
         }
        
         else
         {
            $this->sign_up_model->add($data);
            echo json_encode(["success" => true]);
         }
   }

}