<?php
namespace App\Models;
use CodeIgniter\Model;
use CodeIgniter\Cache\CacheInterface;
class resume_model extends Model 
{
    protected function initialize()

    {
        $this->db_read                  = \Config\Database::connect();
        $this->db_write                 = \Config\Database::connect();
        $this->resume                     = $this->db_write->table('resume');
    }    

    public function add($data)
    {
        $this->resume->insert($data);
        return $this->db_write->insertID();
    }
    
  public function resume_id_exist($resume_id)
    {
        $sql ="SELECT resume_id,qualification,passing_year,edu_desp,company_name,job_position,start_date,end_date,exp_desp,photo
                FROM resume
                 WHERE resume_id = ? 
                   LIMIT 1";
                $query = $this->db->query($sql,array($resume_id));
                return $query->getrow();
    }
    
    
}