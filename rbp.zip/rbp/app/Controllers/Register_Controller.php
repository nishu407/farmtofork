<?php
namespace App\Controllers;
class Register_Controller extends BaseController
{

    public function __construct()
   {
        $this->request             = \Config\Services::request();
        $this->uri                 = new \CodeIgniter\HTTP\URI();
        $this->session             = \Config\Services::session();
        $this->register_model      = model('register_model');
        $this->user_id             = $this->session->get('user_id');
   }
    public function index()
    {
        $data = array(); 
        return view('register_view', $data); 
    }

     public function sign_up()
   {
      $registration_date         = $this->request->getPost('registration_date');
      $firstname                 = $this->request->getPost('firstname');
      $middlename                = $this->request->getPost('middlename');
      $lastname                  = $this->request->getPost('lastname');
      $email                     = $this->request->getPost('email');
      $password                  = password_hash( $this->request->getPost('password'), PASSWORD_DEFAULT );
      $confirmpassword           = $this->request->getPost('confirmpassword');
      $mobile                    = $this->request->getPost('mobile');
      $skill_occupation          = $this->request->getPost('skill_occupation');
      $biography                 = $this->request->getPost('biography');

      $data = 
      [
         'registration_date'     => $registration_date,
         'firstname'             => $firstname,
         'lastname'              => $lastname,
         'email'                 => $email,
         'password'              => $password,
         'mobile'                => $mobile,
         'skill_occupation'      => $skill_occupation,
         'biography'             => $biography,
      ];

      $is_email_exist = $this->register_model->is_email_exist( $email,  $this->user_id );
      if( $is_email_exist )
      {
         echo json_encode( array( "error" => 'This email is already registered' ) );
      }
      else
      {
         $this->register_model->add_student($data);
         echo json_encode(["success" => true]);
      }
   }

}