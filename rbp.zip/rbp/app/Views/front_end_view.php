<!DOCTYPE html>
<html lang="en">
<head>
  <title>Praja Become Raja</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
<nav class="navbar navbar-expand-sm navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="index.php">Jobs</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mynavbar">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="mynavbar">
      <ul class="navbar-nav me-auto">
        <li class="nav-item">
          <a class="navbar-brand" href="#employer">Employer</a>
        </li>
        <li class="nav-item">
          <a class="navbar-brand" href="#appliedcandidates">Applied Candidates</a>
        </li>
      </ul>
      <a class="navbar-brand">
        <img src="asset\src\images\logo.png." alt="prajabecomeraja" style="width:300px;"> 
      </a>
    </div>
    
  </div>
</nav>
<br>
<div class="text-center">
  <img src="asset\src\images\prajabecomeraja.jpg" class="rounded" alt="prajabecomerajapage">
</div><br><br>
<div class="container">
  <div class="row">
    <div class="ab" style="width:500px; height: 120px; border: 1px solid black; background-color: white; margin: 60px; display: flex; flex-direction: column; align-items: center; justify-content: center;  box-shadow: 0px 0px 3px 3px gray;">
      <i class='fas fa-user-alt' style='font-size:40px;color:red'></i>
      <h3><a href="<?php echo base_url()?>login" class="nav-link">Candidate Login</a>
    </div>
    <div class="ab" style="width:500px; height: 120px; border: 1px solid black; background-color: white; margin: 60px; display: flex; flex-direction: column; align-items: center; justify-content: center; box-shadow: 0px 0px 3px 3px gray;">
      <i class='fas fa-diagnoses' style='font-size:48px;color:red'></i>
      <h3><a href="index2.php">Employees Login</h3></a>
    </div>
  </div>
</div>
<br><br>
 <div class="text-center">
    <h3>Popular Job Categories</h3>
    <p>100+jobs live - added today</p>
  </div>
  <div class="container">
  <div class="row">
    <div class="ab" style="width:200px; height: 120px; border: 1px solid black; margin: 60px; display: flex; flex-direction: column; align-items: center; justify-content: center;">
  <i class='fas fa-file-invoice' style='font-size:48px;color:blue;'></i>
  <b style="text-align: center;">Accounting/Finance<br>(0 open positions)</b>
</div>
    
    <div class="ab" style="width:200px; height: 120px; border: 1px solid black; margin: 60px; display: flex; flex-direction: column; align-items: center; justify-content: center;">
      <i class='fas fa-bullhorn' style='font-size:48px;color:red;'></i>
      <b style="text-align: center;">Marketing<br>(1 open position)</b>
    </div>
    
    <div class="ab" align="center" style="width:200px; height: 120px; border: 1px solid black; margin: 60px; display: flex; flex-direction: column; align-items: center; justify-content: center;">
      <i class='fas fa-bezier-curve' style='font-size:48px;color:purple;'></i>
      <b style="text-align: center;">Design<br>(3 open positions)</b>
    </div>
    
    <div class="ab" align="center" style="width:200px; height: 120px; border: 1px solid black; margin: 60px; display: flex; flex-direction: column; align-items: center; justify-content: center;">
      <i class="fa fa-building" style="font-size:48px;color:orange;"></i>
      <b style="text-align: center;">Development<br>(0 open positions)</b>
    </div>
  </div>
</div>

<div class="container">
  <div class="row">
    <div class="ab" align="center" style="width:200px; height: 120px; border: 1px solid black; margin: 60px; margin-top:1px; display: flex; flex-direction: column; align-items: center; justify-content: center;">
      <i class="fas fa-address-book" style="font-size:35px;color:red;"></i>
      <b style="text-align: center;">Project Management<br>(0 open positions)</b>
    </div>
    
    <div class="ab" align="center" style="width:200px; height: 120px; border: 1px solid black; margin: 60px; margin-top:1px; display: flex; flex-direction: column; align-items: center; justify-content: center;">
      <i class="fa fa-user-circle" style="font-size:48px;color:orange;"></i>
      <b style="text-align: center;">Customer Service<br>(0 open positions)</b>
    </div>
    
    <div class="ab" align="center" style="width:200px; height: 120px; border: 1px solid black; margin: 60px; margin-top:1px; display: flex; flex-direction: column; align-items: center; justify-content: center;">
      <i class='fas fa-medkit' style='font-size:48px;color:purple;'></i>
      <b style="text-align: center;">Health and Care<br>(1 open position)</b>
    </div>
    
    <div class="ab" align="center" style="width:200px; height: 120px; border: 1px solid black; margin: 60px; margin-top:1px; display: flex; flex-direction: column; align-items: center; justify-content: center;">
      <i class='fas fa-car-alt' style='font-size:48px;color:blue;'></i>
      <b style="text-align: center;">Automotive Jobs<br>(0 open positions)</b>
    </div>
  </div>
</div>


<footer class="bg-dark text-white text-center text-lg-start">
  <!-- Grid container -->
  <div class="container p-4">
    <!--Grid row-->
    <div class="row">
      <!--Grid column-->
      <div class="col-lg-6 col-md-12 mb-4 mb-md-0">
        <img src="../prajabecomeraja/img/prajabecomeraja.jpg" alt="prajabecomeraja" style="width:300px;margin-left: 100px;">
      </div>
      <!--Grid column-->

      <!--Grid column-->
      <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
        <h5 class="text-uppercase">For Candidates</h5>

        <ul class="list-unstyled mb-0">
          <li>
            <div class="text-white">Brows Jobs</div>
          </li>
          <li>
            <div class="text-white">Brows Candidates</div>
          </li>
          <li>
            <div class="text-white">Candidate Dashboard</div>
          </li>
          <li>
            <div class="text-white">Jobs Alerts</div>
          </li>
          <li>
            <div class="text-white">My Bookmarks</div>
          </li>
        </ul>
      </div>
      <!--Grid column-->

      <!--Grid column-->
      <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
        <h5 class="text-uppercase mb-0">For Employers</h5>
        <ul class="list-unstyled mb-0">
          <li>
            <div class="text-white">All Employers</div>
          </li>
          <li>
            <div class="text-white">Employers Dashboard</div>
          </li>
          <li>
            <div class="text-white">Submit Jobs</div>
          </li>
          <li>
            <div class="text-white">Jobs Packages</div>
          </li>
        </ul>
      </div>
      <!--Grid column-->
    </div>
    <!--Grid row-->
  </div>
  <!-- Grid container -->

  <!-- Copyright -->
  <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
    © 2024 Praja Become Raja. All Right Reserved.
    <a class="text-white">Managed By – Team Praja Become Raja.</a>
  </div>

  <!-- Copyright -->
</footer>

</body>
</html>