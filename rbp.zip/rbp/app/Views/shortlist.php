<!DOCTYPE html>
<head>
	<style type="text/css">
		body {
    font-family: Arial, sans-serif;
}

#openFormBtn {
    padding: 10px 20px;
    font-size: 16px;
    cursor: pointer;
}

.popup-form {
    display: none;
    position: fixed;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5);
    justify-content: center;
    align-items: center;
}

.popup-content {
    background-color: white;
    padding: 20px;
    border-radius: 5px;
    width: 300px;
    text-align: center;
}

.popup-content h2 {
    margin-bottom: 20px;
}

.close {
    position: absolute;
    top: 10px;
    right: 10px;
    font-size: 24px;
    cursor: pointer;
}

form {
    display: flex;
    flex-direction: column;
    align-items: center;
}

input {
    width: 80%;
    padding: 10px;
    margin: 5px 0;
    font-size: 16px;
}

button {
    padding: 10px 20px;
    font-size: 16px;
    cursor: pointer;
    background-color: #4CAF50;
    color: white;
    border: none;
    border-radius: 5px;
}

button:hover {
    background-color: #45a049;
}
	</style>
</head>
	<body>
		<div class="pre-loader">
			<div class="pre-loader-box">
				<div class="loader-logo">
					<img src="<?=base_url()?>asset/vendors/images/logo.png" alt="" />
				</div>
				<div class="loader-progress" id="progress_div">
					<div class="bar" id="bar1"></div>
				</div>
				<div class="percent" id="percent1">0%</div>
				<div class="loading-text">Loading...</div>
			</div>
		</div>
<div class="mobile-menu-overlay"></div>

		<div class="main-container">
			<div class="pd-ltr-20 xs-pd-20-10">
				<div class="min-height-200px">
					<div class="page-header">
						<div class="row">
							<div class="col-md-6 col-sm-12">
								<div class="title">
									<h4>DataTable</h4>
								</div>
								<nav aria-label="breadcrumb" role="navigation">
									<ol class="breadcrumb">
										<li class="breadcrumb-item">
											<a href="index.html">Home</a>
										</li>
										<li class="breadcrumb-item active" aria-current="page">
											DataTable
										</li>
									</ol>
								</nav>
							</div>
							<div class="col-md-6 col-sm-12 text-right">
								<div class="dropdown">
									<a
										class="btn btn-primary dropdown-toggle"
										href="#"
										role="button"
										data-toggle="dropdown"
									>
										January 2018
									</a>
									<div class="dropdown-menu dropdown-menu-right">
										<a class="dropdown-item" href="#">Export List</a>
										<a class="dropdown-item" href="#">Policies</a>
										<a class="dropdown-item" href="#">View Assets</a>
									</div>
								</div>
							</div>
						</div>
					</div>
					<!-- Simple Datatable start -->
					<div class="card-box mb-30">
						<div class="pd-20">
							<h4 class="text-blue h4">Student Apply Jobs</h4>
							<!-- <p class="mb-0">
								you can find more options
								<a
									class="text-primary"
									href="https://datatables.net/"
									target="_blank"
									>Click Here</a
								>
							</p> -->
						</div>
						<div class="pb-20">
							<table class="data-table table stripe hover nowrap">
								<thead>
									

    <!-- Button to open the popup form -->

    <!-- The Popup Form -->
    			
								<div
									class="modal fade"
									id="Medium-modal"
									tabindex="-1"
									role="dialog"
									aria-labelledby="myLargeModalLabel"
									aria-hidden="true"
								>
									<div class="modal-dialog modal-dialog-centered">
										<div class="modal-content">
											<div class="modal-header">
												<h4 class="modal-title" id="myLargeModalLabel">
												Company details
												</h4>
												<button
													type="button"
													class="close"
													data-dismiss="modal"
													aria-hidden="true"
												>
													×
												</button>
											</div>
											<div class="modal-body">
<form id="details_form" class="details_form" action="javascript:void(0)" method="post">
                <label for="name">Date</label>
                <input type="date" id="date" name="date" required><br><br>
                <label for="name">Company</label>
                <input type="text" id="company_name" name="company_name" required><br><br>
                
                <label for="name">Job Position</label>
                <input type="text" id="job_position" name="job_position" required><br><br>
                <label for="name">Location</label>
                <input type="map" id="location" name="location" required><br><br>


 <button class="btn btn-danger btn-lg" name="details_button" id="details_button">submit</button>
         <div id="user_error" class="text-danger" role="alert" style="display:none;"></div>
            </form>
											</div>
											<div class="modal-footer">
												<button
													type="button"
													class="btn btn-secondary"
													data-dismiss="modal"
												>
													Close
												</button>
												<button type="button" class="btn btn-primary">
													Save changes
												</button>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						
									<tr>
										<th>Sr No</th>
                    <th>Name</th>
										<th>Category</th>
										<th>Selected Candidate</th>

										<th>Action</th>
									</tr>
								</thead>
								<tbody id="resp">
                                           
                                            <?php $i=1;
                        foreach ($user_data as $user) { ?>
                            <tr>
                            	<td><?php echo $i++; ?></td>
                              <td><?php echo $user['name']; ?></td>
                                <td><?php echo $user['category']; ?></td>
                                <td>  
<button class="btn-sucuss" data-toggle="modal" data-target="#Medium-modal"type="button">Interview<br>Schedule</button>
</td>
                                <td>
                                    <a class="btn btn-light delete-user-data" id="delete-user-data" href="javascript:void(0)" data-id="<?php //echo $user['user_id']; ?>"><i class="fa fa-trash"></i></a>
                                </td>
                              		
                            </tr>
                    <?php } ?>
									
							
                      
                      </tbody>
							</table>
						</div>
					</div>
					
				
			</div>
		</div>

				
			
			</div>
		</div>
		<!-- welcome modal start -->


    <!-- The Popup Form -->
    <div id="popupForm" class="popup-form">
        <div class="popup-content">
            <span id="closeFormBtn" class="close">&times;</span>
            
        </div>
    </div>

    <script src="script.js"></script>
</body>
</html>

		
		<!-- welcome modal end -->
		<!-- js -->
		<script src="vendors/scripts/core.js"></script>
		<script src="vendors/scripts/script.min.js"></script>
		<script src="vendors/scripts/process.js"></script>
		<script src="vendors/scripts/layout-settings.js"></script>
		<!-- Google Tag Manager (noscript) -->
		<noscript
			><iframe
				src="https://www.googletagmanager.com/ns.html?id=GTM-NXZMQSS"
				height="0"
				width="0"
				style="display: none; visibility: hidden"
			></iframe
		></noscript>
		<!-- End Google Tag Manager (noscript) -->
		<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>var baseUrl = '<?php echo base_url();?>';</script>
	<script type="text/javascript" src="<?php echo base_url()?>asset/src/scripts/update_profile.js"></script>
		<script type="text/javascript" src="<?php echo base_url()?>asset/src/scripts/script.js"></script>


	</body>
</html>
