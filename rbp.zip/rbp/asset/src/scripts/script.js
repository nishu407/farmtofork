// Get the elements
const openFormBtn = document.getElementById("openFormBtn");
const popupForm = document.getElementById("popupForm");
const closeFormBtn = document.getElementById("closeFormBtn");

// Open the form when the button is clicked
openFormBtn.addEventListener("click", function() {
    popupForm.style.display = "flex";
});

// Close the form when the close button is clicked
closeFormBtn.addEventListener("click", function() {
    popupForm.style.display = "none";
});

// Close the form if the user clicks outside the popup content
window.addEventListener("click", function(event) {
    if (event.target === popupForm) {
        popupForm.style.display = "none";
    }
});
