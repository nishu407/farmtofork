<!DOCTYPE html>
<html>
	<head>
		<!-- Basic Page Info -->
		<meta charset="utf-8" />
		<title>Praja become raja</title>

		<!-- Site favicon -->
		<link
			rel="apple-touch-icon"
			sizes="180x180"
			href="<?=base_url()?>asset/vendors/images/apple-touch-icon.png"
		/>
		<link
			rel="icon"
			type="image/png"
			sizes="32x32"
			href="<?=base_url()?>asset/vendors/images/favicon-32x32.png"
		/>
		<link
			rel="icon"
			type="image/png"
			sizes="16x16"
			href="<?=base_url()?>asset/vendors/images/favicon-16x16.png"
		/>

		<!-- Mobile Specific Metas -->
		<meta
			name="viewport"
			content="width=device-width, initial-scale=1, maximum-scale=1"
		/>

		<!-- Google Font -->
		<link
			href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap"
			rel="stylesheet"
		/>
		<!-- CSS -->
		<link rel="stylesheet" type="text/css" href="<?=base_url()?>asset/vendors/styles/core.css" />
		<link
			rel="stylesheet"
			type="text/css"
			href="<?=base_url()?>asset/vendors/styles/icon-font.min.css"
		/>
		<link
			rel="stylesheet"
			type="text/css"
			href="<?=base_url()?>asset/src/plugins/jquery-steps/jquery.steps.css"
		/>
		<link rel="stylesheet" type="text/css" href="<?=base_url()?>asset/vendors/styles/style.css" />

		<!-- Global site tag (gtag.js) - Google Analytics -->
		<script
			async
			src="https://www.googletagmanager.com/gtag/js?id=G-GBZ3SGGX85"
		></script>
		<script
			async
			src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-2973766580778258"
			crossorigin="anonymous"
		></script>
		<script>
			window.dataLayer = window.dataLayer || [];
			function gtag() {
				dataLayer.push(arguments);
			}
			gtag("js", new Date());

			gtag("config", "G-GBZ3SGGX85");
		</script>
		<!-- Google Tag Manager -->
		<script>
			(function (w, d, s, l, i) {
				w[l] = w[l] || [];
				w[l].push({ "gtm.start": new Date().getTime(), event: "gtm.js" });
				var f = d.getElementsByTagName(s)[0],
					j = d.createElement(s),
					dl = l != "dataLayer" ? "&l=" + l : "";
				j.async = true;
				j.src = "https://www.googletagmanager.com/gtm.js?id=" + i + dl;
				f.parentNode.insertBefore(j, f);
			})(window, document, "script", "dataLayer", "GTM-NXZMQSS");
		</script>
		<!-- End Google Tag Manager -->
	</head>

	<body class="login-page">
		<div class="login-header box-shadow">
			<div
				class="container-fluid d-flex justify-content-between align-items-center"
			>
				<div class="brand-logo">
					<a href="login.html">
						<img src="<?=base_url()?>asset/vendors/images/logo.png" alt="" />
					</a>
				</div>
				<div class="login-menu">
					<ul>
						<li><a href="login.html">Login</a></li>
					</ul>
				</div>
			</div>
		</div>
		<div
			class="register-page-wrap d-flex align-items-center flex-wrap justify-content-center"
		>
			<div class="container">
				<div class="row align-items-center">
					<div class="col-md-6 col-lg-6">
						<img src="<?=base_url()?>asset/vendors/images/register-page-img.png" alt="" />
						<img src="<?=base_url()?>asset/vendors/images/register-page-img.png" alt="" />

					</div> 
					<div class="col-md-6 col-lg-6">
						<!-- <div class="register-box bg-white box-shadow border-radius-5"> -->
							<div class="wizard-content">
         <form id="adduser" class="adduser" action="javascript:void(0)" method="post">
  
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="first name"><b> Name</b></label>
      <input type="text" class="form-control" id="name" name="name" placeholder="Enter  Name">
    </div>
    <div class="form-group col-md-6">
      <label for="skill_occupation"><b>Address</b></label>
      <input type="text" class="form-control" id="address" name="address" placeholder="Enter Your Address">
    </div></div>
        <div class="form-row">
 <div class="form-group col-md-6">
      <label for="inputPassword4"><b>Dob</b></label>
      <input type="date" class="form-control" id="dob" name="dob" placeholder="Enter date of Birth ">
    </div>
    <div class="form-group col-md-6 ">
  <label for="biography"><b>Gender</b></label>
<label class="check"><input type="radio" class="iradio" name="gender" id="gender"/>Male</label>
 <label class="check"><input type="radio" class="iradio" name="gender" id="gender" />Female</label></div>
  </div>
  <div class="form-row">
  <div class="form-group col-md-6">
    <label for="mobile"><b>Mobile No.</b></label>
 <input type="mobile" class="form-control" id="mobile_no" name="mobile_no" placeholder="Enter Mobile No.">
  </div> 
   <div class="form-group col-md-6">
    <label for="email"><b>Email</b></label>
      <input type="email" class="form-control" id="email" name="email" placeholder="Enter Email">
  </div> </div>
    <div class="form-row">
    <div class="form-group col-md-6">
       <label for="password"><b>Password</b></label>
      <input type="password" class="form-control" id="password" name="password" placeholder="Enter Password"><i class="fa-solid fa-eye" id="show-password" style="position: absolute; top: 60%; cursor: pointer; color: black; margin-left:80%;"></i>
    </div>
    <div class="form-group col-md-6">
     <label for="confirm password"><b>Confirm Password</b></label>
      <input type="password" class="form-control" id="confirmpassword" name="confirmpassword" placeholder="Enter Confirm Password"><i class="fa-solid fa-eye" id="show-password" style="position: absolute; top: 60%; cursor: pointer; color: black; margin-left:80%;"></i>
    </div>
  </div>
  
   <div class="form-row">
    
    <div class="form-group col-md-6">
      <label for="qualification"><b>Qualification</b></label>
      <input type="text" class="form-control" id="qualification" name="qualification" placeholder="Enter Your Qualification">
    </div>

    <div class="form-group col-md-6">
      <label for="experience_time"><b>Experience Time</b></label>
      <input type="text" class="form-control" id="experience_time" name="experience_time" placeholder="Enter Your Qualification">
    </div>
    <div class="form-group col-md-6">
    <label for="mobile"><b>Language</b></label>
    <label>optinal</label>
     
      <select id="language" class="custom-select col-06"  name="language" data-placeholder="Enter Language."style="width: 100%">
    <optgroup label="">
	 <option value="select" selected>Select</option>
<option value="Marathi">Marathi</option>
	<option value="Hindi">Hindi</option>
	<option value="English">English</option>
	<option value="Other">Other</option>
</optgroup></select>


  </div>  
    <div class="form-group col-md-6">
      <label for="photo"><b>Photo</b></label>
      <input type="file" class="form-control" id="photo" name="photo">
    </div>
  </div>
  <div class="form-row">
  <div class="form-group col-md-6">
    <label for="mobile"><b>Salary type</b></label>
    <select class="custom-select-form-control col-06"name="salary_type" id="salary_type"  style="width: 100%; height: 38px" placeholder="Enter salary type.">
<optgroup label="">
		 <option value="select" selected>Select</option>
<option value="Monthly">Monthly</option>
<option value="Weekly">Weekly</option>
<option value="Daily">Daily</option>
<option value="Hourly">Hourly</option>
<option value="Yearly">Yearly</option>
</optgroup>
</select>									
  </div>
   <div class="form-group col-md-6">
    <label for="mobile"><b>Salary</b></label>
      <input type="text" class="form-control" id="salary" name="salary" placeholder="Enter Salary.">
  </div>  
   </div>
   <div class="form-row">
  <div class="form-group col-md-6">
    <label for="mobile"><b>Category</b></label>
    <select class="custom-select col-06" id="category" name="category" placeholder="Enter Category."style="width: 100%">
    <optgroup label="">
    		 <option value="select" selected>Select</option>
<option value="Advertising">Advertising</option>
	<option value="Application">Application</option>
	<option value="Customer executive">Customer executive</option>
	<option value="Design">Design</option>
	<option value="Web_Devloper">Web Devloper</option>
	<option value="category">Office executive</option>
</optgroup></select>
  </div>
  <div class="form-group col-md-6">
      <label for="biography"><b>job Position</b></label>
      <input type="text" class="form-control" id="job_position" name="job_position" placeholder="Enter Your Qualification">
    </div></div>
        <div class="checkbox">
      <label><input type="checkbox">Accept Term and Condition.</label>
    </div>
        <button class="btn btn-primary btn-block btn-signin" name="sign_up_button" id="sign_up_button">Sign Up</button>
         <div id="user_error" class="text-danger" role="alert" style="display:none;"></div>

        <p class="mg-t-40 mg-b-0"><strong>Already have an account? </strong><br>
        	<a class="btn btn-primary" href="login">Login</a></p>
          </form>
							</div>
						<!-- </div> -->
					</div>
				</div>
			</div>
		</div>
		<!-- success Popup html Start -->
		<button
			type="button"
			id="success-modal-btn"
			hidden
			data-toggle="modal"
			data-target="#success-modal"
			data-backdrop="static"
		>
			Launch modal
		</button>
		<div
			class="modal fade"
			id="success-modal"
			tabindex="-1"
			role="dialog"
			aria-labelledby="exampleModalCenterTitle"
			aria-hidden="true"
		>
			<div
				class="modal-dialog modal-dialog-centered max-width-400"
				role="document"
			>
				<div class="modal-content">
					<div class="modal-body text-center font-18">
						<h3 class="mb-20">Form Submitted!</h3>
						<div class="mb-30 text-center">
							<img src="<?=base_url()?>asset/vendors/images/success.png" />
						</div>
						Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do
						eiusmod
					</div>
					<div class="modal-footer justify-content-center">
						<a href="<?php echo base_url();?>login" class="btn btn-primary">Done</a>
					</div>
				</div>
			</div>
		</div>
		<!-- success Popup html End -->
		<!-- welcome modal start -->

		<!-- welcome modal end -->
		<!-- js -->
		<script src="<?=base_url()?>asset/vendors/scripts/core.js"></script>
		<script src="<?=base_url()?>asset/vendors/scripts/script.min.js"></script>
		<script src="<?=base_url()?>asset/vendors/scripts/process.js"></script>
		<script src="<?=base_url()?>asset/vendors/scripts/layout-settings.js"></script>
		<script src="<?=base_url()?>asset/src/plugins/jquery-steps/jquery.steps.js"></script>
		<script src="<?=base_url()?>asset/vendors/scripts/steps-setting.js"></script>
		<!-- Google Tag Manager (noscript) -->
		<noscript
			><iframe
				src="https://www.googletagmanager.com/ns.html?id=GTM-NXZMQSS"
				height="0"
				width="0"
				style="display: none; visibility: hidden"
			></iframe
		></noscript>
		<!-- End Google Tag Manager (noscript) -->
	<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>var baseUrl = '<?php echo base_url();?>';</script>
<script type="text/javascript" src="<?php echo base_url()?>asset/src/scripts/sign_up.js"></script>
	</body>
</html>