<?php
namespace App\Models;
use CodeIgniter\Model;
use CodeIgniter\Cache\CacheInterface;
class shortlist_model extends Model 
{
    protected function initialize()

    {
        $this->db_read                  = \Config\Database::connect();
        $this->db_write                 = \Config\Database::connect();
        $this->register                     = $this->db_write->table('register');
    }
    
public function add($data)
    {
        $this->details->insert($data);
        return $this->db_write->insertID();
    }
  public function user_id_exist( $user_id)
    {
         $sql = "SELECT *
                FROM register
                ORDER BY user_id DESC";
                $query = $this->db_read->query($sql);
                return $query->getResultArray();
    }
    
}