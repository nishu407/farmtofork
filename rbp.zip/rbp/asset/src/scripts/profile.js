$(document).ready(function () 
{
  $(document).on('click','#profile_button',function()
  {
    __user_profile_info();
  });

}); 

var __user_profile_info_xhr = null;
var __user_profile_info = function(form)
{

  $("#user_login #user_error").html("").hide();
  if( __user_profile_info_xhr != null )
  { 
    __user_profile_info_xhr.abort();
    __user_profile_info_xhr = null;
  }

  var user_id                 =$('#profile_form  #my_profile_edit').val();
  var registration_date       =$('#profile_form  #registration_date').val();
  var firstname               =$('#profile_form  #firstname').val(); 
  var lastname                =$('#profile_form  #lastname').val();
  var email                   =$('#profile_form  #email').val();
  var mobile                  =$('#profile_form  #mobile').val();
  var skill_occupation        =$('#profile_form  #skill_occupation').val();
  var biography               =$('#profile_form  #biography').val();

  if( registration_date == '' )
  {
    $("#profile_form #user_error").html( 'Please enter registration date.' ).show();
    return;
  }
  if( firstname == '' )
  {
    $("#profile_form #user_error").html( 'Please enter first name.' ).show();
    return;
  }

  if( lastname == '' )
  {
    $("#profile_form #user_error").html( 'Please enter last name.' ).show();
    return;
  }

  if( email == '' )
  {
    $("#profile_form #user_error").html( 'Please enter email.' ).show();
    return;
  }
 
  if( mobile == '' )
  {
    $("#profile_form #user_error").html( 'Please enter mobile.' ).show();
    return;
  }
  if( skill_occupation == '' )
  {
    $("#profile_form #user_error").html( 'Please enter skill occupation.' ).show();
    return;
  }
  if( biography == '' )
  {
    $("#profile_form #user_error").html( 'Please enter biography.' ).show();
    return;
  }

 

  __user_profile_info_form_xhr = $.ajax(
  {
    type: "POST"
    ,url: baseUrl + "my_profile/my_profile"
    , data: {'user_id' :user_id,'registration_date' :registration_date,'firstname' :firstname,'lastname' :lastname,'email' :email,'mobile': mobile,'skill_occupation' :skill_occupation,'biography' :biography}
    , dataType: 'json'
    , error: function () {
    },

    success: function(response) 
    {           
      if (typeof response.error !== 'undefined' && response.error !== '') 
      {
        console.log("An error occurred: " + response.error);
      } 
      else 
      {
        console.log('Update successful.');
        window.location.href = baseUrl +"dashboard";
      }
    }
  }); 
} 


