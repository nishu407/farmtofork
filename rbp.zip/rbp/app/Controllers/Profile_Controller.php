<?php
namespace App\Controllers;
class Profile_Controller extends BaseController
{
   public function __construct()
   {
      $this->request            = \Config\Services::request();
      $this->uri                = new \CodeIgniter\HTTP\URI();
      $this->session            = \Config\Services::session();
      $this->profile_model       = model('profile_model');
      $this->user_id            = $this->session->get('user_id');
   }

 public function index()
   {
        $user_id            =$this->user_id;
        $data['user_data']     = $this->profile_model->user_id_exist($user_id);
        $data['body_html']  = view('profile',$data);
        $this->_main($data); 
   }


    public function profile()
   {
      $user_id               = $this->request->getPost('user_id');
      $name               = $this->request->getPost('name');
      $mobile_no              = $this->request->getPost('mobile_no');
      $qualification              = $this->request->getPost('qualification');
       $email                    = $this->request->getPost('email');
       $password                 = password_hash( $this->request->getPost('password'), PASSWORD_DEFAULT );
       $confirmpassword          = $this->request->getPost('confirmpassword');
       $dob                 = $this->request->getPost('dob');
      $photo                 = $this->request->getPost('photo');
     $gender                 = $this->request->getPost('gender');
     $experience_time                 = $this->request->getPost('experience_time');
     $language                = $this->request->getPost('language');
      $salary_type                 = $this->request->getPost('salary_type');
     $salary                 = $this->request->getPost('salary');
$category                 = $this->request->getPost('category');
      $job_position                 = $this->request->getPost('job_position');
     $social_network                 = $this->request->getPost('social_network');
    $data = 
      [
         'name'           => $name,
         'mobile_no'          => $mobile_no,
         'qualification'      => $qualification,
         'email'              => $email,
   'password'                 => $password,
         'dob'                => $dob ,
        'photo'              => $photo ,
        'gender'             => $gender ,
        'experience_time'    => $experience_time ,
        'language'             => $language ,
        'salary_type'    => $salary_type ,
        'salary'             => $salary ,
        'category'    => $category ,
        'job_position'             => $job_position ,
        'social_network'    => $social_network 

      ];
  $check = $this->profile_model->profile_info_save($user_id, $data);
      if ($check) 
      {
         echo json_encode(array("success" =>1 ,'error'=>0));
      } 
      else 
      {
         echo json_encode(array("success" => 0 ,'error'=>1));              
      }
   }

      public function profile_delete() 
   {      
        $user_id       = $this->request->getPost('user_id');
        $res           = $this->profile_model->delete_profile($user_id);
       if($res)
        {
                    echo json_encode( array("success" => true) );
                 }
       else
       {
            echo json_encode( array("success" => false) );
 }
   

}
}