$(document).ready(function () {
        $(document).on('click', '.delete-user-data', function () {
             alert('Are you sure you want to delete this user?');
            var user_id  = $(this).data("id");
            $.ajax({
            type: "POST"
            ,url: baseUrl + "profile_delete"
            , data: {user_id :user_id }
            , dataType: 'json'
            , error: function () {}
            , success: function( response ){
                         
                },
                        
            }); 

        });
    });