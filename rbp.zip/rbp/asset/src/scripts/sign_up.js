$(document).ready(function () 
{
  $(document).on('click','#sign_up_button',function()
  {
              // alert('hello');

   __user_sign_up_info();
  });

  $("#adduser").validate(
  {
    ignore: "",
    onkeyup: false,
    onfocusout: false,
    rules: {
        
    },

    messages: { 

    },

    submitHandler: function (form, event) {
    event.preventDefault();
    __user_sign_up_info(form);
    }
  });

}); 

var __user_sign_up_info_xhr = null;
var __user_sign_up_info = function(form)
{

  $("#user_login #user_error").html("").hide();
  if( __user_sign_up_info_xhr != null )
  { 
    __user_sign_up_info_xhr.abort();
    __user_sign_up_info_xhr = null;
  }

  var name               =$('#adduser  #name').val(); 
   var address               =$('#adduser  #address').val(); 
     var dob                =$('#adduser  #dob').val();
  var gender             =$('#adduser #gender').val();
var mobile_no              =$('#adduser  #mobile_no').val();
  var email                   =$('#adduser  #email').val();
  var password                =$('#adduser  #password').val();  
  var confirmpassword         =$('#adduser  #confirmpassword').val();
    var qualification          =$('#adduser  #qualification').val();
  var experience_time     =$('#adduser #experience_time').val();
   var language               =$('#adduser  #language').val(); 
     var photo              =$('#adduser  #photo').val();
var salary_type              =$('#adduser  #salary_type').val();
  var salary          =$('#adduser  #salary').val();
  var category              =$('#adduser  #category').val();
  var job_position          =$('#adduser  #job_position').val();


  if( name == '' )
  {
    $("#adduser #user_error").html( 'Please enter full name.' ).show();
    return;
  }
  if(address == '' )
  {
    $("#adduser #user_error").html( 'Please enter address.' ).show();
    return;
  }
  if( dob == '' )
  {
    $("#adduser #user_error").html( 'Please enter dob.' ).show();
    return;
  }
   if (gender=='')
   {
    $("#adduser #user_error").html('Please select gender').show();
    return;
   }

  if( mobile_no == '' )
  {
    $("#adduser #user_error").html( 'Please enter mobile_no.' ).show();
    return;
  }
  if( email == '' )
  {
    $("#adduser #user_error").html( 'Please enter email.' ).show();
    return;
  }
  if( password == '' )
  {
    $("#adduser #user_error").html( 'Please enter the password.' ).show();
    return;
  }
  if(confirmpassword == '' )
  {
    $("#adduser #user_error").html( 'Please enter confirmpassword.' ).show();
    return;
  }

  if( qualification == '' )
  {
    $("#adduser #user_error").html( 'Please enter Qualification.' ).show();
    return;
  }
  
if (experience_time=='')
   {
    $("#adduser #user_error").html('Please enter experience_time').show();
    return;
   }
  
   if (language=='')
   {
    $("#adduser #user_error").html('Please enter language').show();
    return;
   }
    if (photo=='')
   {
    $("#adduser #user_error").html('Please enter Photo').show();
    return;
   }


  if (salary_type=='')
   {
    $("#adduser #user_error").html('Please enter salary type').show();
    return;
   }


  if (salary=='')
   {
    $("#adduser #user_error").html('Please enter salary').show();
    return;
   }

 if (category=='')
   {
    $("#adduser #user_error").html('Please enter category').show();
    return;
   }
   if (job_position=='')
   {
    $("#adduser #user_error").html('Please enter job_position').show();
    return;
   }
  __user_sign_up_info_form_xhr = $.ajax(
  {
    type: "POST"
    ,url: baseUrl + "sign_up/sign_up"
    , data: {'name' :name,'address':address,'dob' :dob,'gender':gender,'mobile_no' :mobile_no,'email' :email,'password' :password,'confirmpassword' :confirmpassword,'qualification' :qualification,'experience_time':experience_time,'language':language,'photo':photo,'salary_type':salary_type,'salary':salary,'category':category,'job_position':job_position}
    , dataType: 'json'
    , error: function () {
    },

    success: function(response) 
    {
      if (typeof response.error !== 'undefined' && response.error !== '') 
      {
        console.log("An error occurred: " + response.error);
      } 
      else 
      {

        console.log('Login successful.');
        window.location.href = baseUrl +"login";
      }
    }
  }); 
} 


