<?php
namespace App\Controllers;
class Change_Controller extends BaseController
{

    public function __construct()
   {
        $this->request             = \Config\Services::request();
        $this->uri                 = new \CodeIgniter\HTTP\URI();
        $this->session             = \Config\Services::session();
        $this->change_Model         = model('change_Model');
        $this->user_id             = $this->session->get('user_id');
   }
    public function index()
    {
        $data = array(); 
        $data['body_html']  = view('change_Pass',$data);
         $this->_main($data); 
 
    }

  
}