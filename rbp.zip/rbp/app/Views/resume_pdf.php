
		<div class="mobile-menu-overlay"></div>

		<div class="main-container">
			<div class="pd-ltr-20 xs-pd-20-10">
				<div class="min-height-200px">
					<div class="page-header">
						<div class="row">
							<div class="col-md-6 col-sm-12">
								<!-- <div class="title">
									<h4>Form</h4>
								</div> -->
								<!-- <nav aria-label="breadcrumb" role="navigation">
									<ol class="breadcrumb">
										<li class="breadcrumb-item">
											<a href="index.html">Home</a>
										</li>
										<li class="breadcrumb-item active" aria-current="page">
											Form
										</li>
									</ol>
								</nav> -->
							</div>
							<div class="col-md-6 col-sm-12 text-right">
								<div class="dropdown">
									<a
										class="btn btn-primary dropdown-toggle"
										href="#"
										role="button"
										data-toggle="dropdown"
									>
										January 2018
									</a>
									<div class="dropdown-menu dropdown-menu-right">
										<a class="dropdown-item" href="#">Export List</a>
										<a class="dropdown-item" href="#">Policies</a>
										<a class="dropdown-item" href="#">View Assets</a>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="invoice-wrap">
						<div class="invoice-box">
							<div class="invoice-header">
								<div class="logo text-center">
									<img src="vendors/images/deskapp-logo.png" alt="" />
								</div>
							</div>
							<h4 class="text-center mb-30 weight-600">RESUME</h4>
							<div class="row pb-30">
								<div class="col-md-6">
									<h5 class="mb-15">job position</h5>
									<p class="font-14 mb-5">
										start date: <strong class="weight-600">10 Jan 2018</strong>
									</p>
									<p class="font-14 mb-5">
										end date  <strong class="weight-600">4556</strong>
									</p>
								</div>
								<div class="col-md-6">
									<div class="text-right">
										<p class="font-14 mb-5">Your Name</p>
										<p class="font-14 mb-5">Your Address</p>
										<p class="font-14 mb-5">Address</p>
										<p class="font-14 mb-5">Postcode</p>
									</div>
								</div>
							</div>
							<div class="invoice-desc pb-30">
								<div class="invoice-desc-head clearfix">
									<div class="invoice-sub">Description</div>
									<div class="invoice-rate">Qualification</div>
									<div class="invoice-hours">Acedemic Name</div>
									<div class="invoice-subtotal">Passing Year</div>
								</div>
								<div class="invoice-desc-body">
									<ul>
										<li class="clearfix">
											<div class="invoice-sub">Website Design</div>
											<div class="invoice-rate">$20</div>
											<div class="invoice-hours">100</div>
											<div class="invoice-subtotal">
												<span class="weight-600">$2000</span>
											</div>
										</li>
										<li class="clearfix">
											<div class="invoice-sub">Logo Design</div>
											<div class="invoice-rate">$20</div>
											<div class="invoice-hours">100</div>
											<div class="invoice-subtotal">
												<span class="weight-600">$2000</span>
											</div>
										</li>
										<li class="clearfix">
											<div class="invoice-sub">Website Design</div>
											<div class="invoice-rate">$20</div>
											<div class="invoice-hours">100</div>
											<div class="invoice-subtotal">
												<span class="weight-600">$2000</span>
											</div>
										</li>
										<li class="clearfix">
											<div class="invoice-sub">Logo Design</div>
											<div class="invoice-rate">$20</div>
											<div class="invoice-hours">100</div>
											<div class="invoice-subtotal">
												<span class="weight-600">$2000</span>
											</div>
										</li>
									</ul>
								</div>
								
							</div>
							<!-- <h4 class="text-center pb-20">Thank You!!</h4> -->
						</div> 
</div>
				</div>
				
			</div>
		</div>
		<!-- welcome modal start -->
		<div class="welcome-modal">
			<button class="welcome-modal-close">
				<i class="bi bi-x-lg"></i>
			</button>
			<iframe
				class="w-100 border-0"
				src="https://embed.lottiefiles.com/animation/31548"
			></iframe>
			<div class="text-center">
				<h3 class="h5 weight-500 text-center mb-2">
					Open source
					<span role="img" aria-label="gratitude">❤️</span>
				</h3>
				<div class="pb-2">
					<a
						class="github-button"
						href="https://github.com/dropways/deskapp"
						data-color-scheme="no-preference: dark; light: light; dark: light;"
						data-icon="octicon-star"
						data-size="large"
						data-show-count="true"
						aria-label="Star dropways/deskapp dashboard on GitHub"
						>Star</a
					>
					<a
						class="github-button"
						href="https://github.com/dropways/deskapp/fork"
						data-color-scheme="no-preference: dark; light: light; dark: light;"
						data-icon="octicon-repo-forked"
						data-size="large"
						data-show-count="true"
						aria-label="Fork dropways/deskapp dashboard on GitHub"
						>Fork</a
					>
				</div>
			</div>
			<div class="text-center mb-1">
				<div>
					<a
						href="https://github.com/dropways/deskapp"
						target="_blank"
						class="btn btn-light btn-block btn-sm"
					>
						<span class="text-danger weight-600">STAR US</span>
						<span class="weight-600">ON GITHUB</span>
						<i class="fa fa-github"></i>
					</a>
				</div>
				<script
					async
					defer="defer"
					src="https://buttons.github.io/buttons.js"
				></script>
			</div>
			<a
				href="https://github.com/dropways/deskapp"
				target="_blank"
				class="btn btn-success btn-sm mb-0 mb-md-3 w-100"
			>
				DOWNLOAD
				<i class="fa fa-download"></i>
			</a>
			<p class="font-14 text-center mb-1 d-none d-md-block">
				Available in the following technologies:
			</p>
			<div class="d-none d-md-flex justify-content-center h1 mb-0 text-danger">
				<i class="fa fa-html5"></i>
			</div>
		</div>
		<button class="welcome-modal-btn">
			<i class="fa fa-download"></i> Download
		</button>
		<!-- welcome modal end -->
		<!-- js -->
		<script src="vendors/scripts/core.js"></script>
		<script src="vendors/scripts/script.min.js"></script>
		<script src="vendors/scripts/process.js"></script>
		<script src="vendors/scripts/layout-settings.js"></script>
		<!-- Google Tag Manager (noscript) -->
		<noscript
			><iframe
				src="https://www.googletagmanager.com/ns.html?id=GTM-NXZMQSS"
				height="0"
				width="0"
				style="display: none; visibility: hidden"
			></iframe
		></noscript>
		<!-- End Google Tag Manager (noscript) -->
	</body>
</html>
