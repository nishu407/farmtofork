<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->get('/dashboard', 'Dashboard_Controller::index');
$routes->get('/front_end_view','Front_Controller::index');
$routes->get('/login','Login_Controller::index');
$routes->get('/sign_up', 'Signup_Controller::index');
$routes->post('/sign_up/sign_up','Signup_Controller::sign_up');
$routes->post('/login/login','Login_Controller::login');
$routes->get('/profile', 'Profile_Controller::index');
$routes->get('/resume', 'Resume_Controller::index');
$routes->get('/apply', 'Apply_Controller::index');
$routes->get('/shortlist', 'Shortlist_Controller::index');
$routes->post('/resume', 'Resume_Controller::resume');
$routes->post('/profile', 'Profile_Controller::profile');
$routes->post('/profile', 'Profile_Controller::profile_delete');
$routes->get('/change_Pass','Change_Controller::index');
$routes->get('/resume_pdf', 'Resume_Controller::resume_view');
$routes->get('apply/approve/(:num)', 'Apply_Controller::approve/$1');
$routes->get('apply/disapprove/(:num)', 'Apply_Controller::disapprove/$1');
$routes->post('/shortlist', 'Shortlist_Controller::details');
