<?php
namespace App\Models;
use CodeIgniter\Model;
use CodeIgniter\Cache\CacheInterface;
class apply_model extends Model 
{
    protected function initialize()

    {
        $this->db_read                  = \Config\Database::connect();
        $this->db_write                 = \Config\Database::connect();
        $this->register                     = $this->db_write->table('register');
    }
    
  // 
   
   public function user_id_exist( $user_id)
    {
        $sql = "SELECT name,address,mobile_no,qualification,dob,photo,experience_time,gender,email ,language,salary_type,salary,category,job_position
                FROM register
                ORDER BY user_id DESC";
                $query = $this->db_read->query($sql);
                return $query->getResultArray();
    } 
}