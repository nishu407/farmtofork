<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Praja Become Raja</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"> <!-- Font Awesome CDN -->
    <style>
        body {
            background-color: black;
            margin: 0;
            font-family: Arial, sans-serif;
        }
        .navbar {
            display: flex;
            align-items: center;
            background-color: black; 
            padding: 10px 20px; /* Add padding to the navbar */
        }
        .logo-container {
            flex-grow: 0; /* Prevent logo from growing */
            text-align: center; /* Center logo */
            margin: 0 20px; /* Adjust margins as needed */
        }
        .navbar img {
            height: 80px; /* Adjust logo size */
        }
        .contact-info {
            color: white;
            display: flex; /* Use flexbox for contact info */
            align-items: center; /* Center items vertically */
            margin: 0 20px; /* Add spacing */
        }
        .contact-info p {
            margin: 0 0 0 10px; /* Add left margin to the text */
        }
        .icon-circle {
            width: 60px; /* Set width for the circle */
            height: 60px; /* Set height for the circle */
            border-radius: 50%; /* Make it round */
            background-color: green; /* Circle color */
            display: flex; /* Use flexbox for centering the icon */
            justify-content: center; /* Center horizontally */
            align-items: center; /* Center vertically */
        }
        .navbar-container {
            display: flex;
            justify-content: center; /* Center all items */
            width: 100%;
        }
        hr {
            border: 0; /* Remove default border */
            height: 2px; /* Height of the line */
            background-color: white; /* Change this to your desired color */
            width: 100%; /* Adjust width as needed */
            margin: 10px auto; /* Center and add margin */
        }

        .container {
            display: flex;
            justify-content: center; /* Center items horizontally */
            flex-wrap: wrap; /* Allow buttons to wrap on smaller screens */
        }
        .btn {
            margin: 20px; /* Add some space between buttons */
            padding: 15px; /* Increase button size */
            font-size: 2.0rem; /* Increase font size */
            width: 300px; /* Set fixed width for buttons */
            border: 3px dotted white; /* Dotted border */
            color: white; /* Set text color to white */
            margin-bottom: 30px;
        }
        .btn-outline-warning {
            background-color: transparent; /* Make background transparent */
            border-color: white; /* Ensure border color is orange */
        }
        .btn-outline-warning:hover {
            background-color: lightlemon; /* Change background on hover */
            color: white; /* Keep text color white on hover */
        }
    </style>
</head>
<body>

    <div class="navbar">
        <div class="navbar-container">
            <div class="contact-info">
                <div class="icon-circle">
                    <i class="fa fa-phone" style="font-size:24px; color:white;"></i>
                </div>
                <p>Call Anytime:<br> +919960749992</p>
            </div>
            <div class="logo-container">
                <img src="asset\src\images\logo.png" alt="Logo"> <!-- Replace with your logo URL -->
            </div>
            <div class="contact-info">
                <div class="icon-circle">
                    <i class="fa fa-envelope" style="font-size:24px; color:white;"></i>
                </div>
                <p>Email Us:<br> info@prajabecomeraja.com</p>
            </div>
        </div>
    </div>

    <hr> <!-- Horizontal line -->

     <div class="logo-container">
        <img src="asset\src\images\logo.png" alt="Logo" height="300px" width="1100px">
    </div>

    <div class="container mt-12"> 
        <div class="row text-center">
            <div class="col-sm-6">
                <button type="button" class="btn btn-outline-warning" style="margin-right: 200px;"><a href="<?php echo base_url()?>front_end_view" class="nav-link">Jobs</a></button>
            </div>
            <div class="col-sm-6">
                <button type="button" class="btn btn-outline-warning">Shopping</button>
            </div>
        </div>
    </div>
    <div class="container mt-12"> 
        <div class="row text-center">
            <div class="col-sm-6">
                <button type="button" class="btn btn-outline-warning" style="margin-right: 200px;">
                    <a href="<?php echo base_url()?>home" class="nav-link">Education</a>
                </button>
            </div>
            <div class="col-sm-6">
                <button type="button" class="btn btn-outline-warning">Manufacturing</button>
            </div>
        </div>
    </div>

</body>
</html>