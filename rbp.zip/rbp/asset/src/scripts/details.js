$(document).ready(function () 
{
  $(document).on('click','#details_button',function()
  {
             alert('hello');

   __user_details_info();
  });

  $("#details_form").validate(
  {
    ignore: "",
    onkeyup: false,
    onfocusout: false,
    rules: {
        
    },

    messages: { 

    },

    submitHandler: function (form, event) {
    event.preventDefault();
    __user_details_info(form);
    }
  });

}); 

var __user_details_info_xhr = null;
var __user_details_info = function(form)
{

  $("#user_login #user_error").html("").hide();
  if( __user_details_info_xhr != null )
  { 
    __user_details_info_xhr.abort();
    __user_details_info_xhr = null;
  }
    var company_name              =$('#details_form  #company_name').val();
  var job_position                =$('#details_form  #job_position').val();  
  var start_date         =$('#details_form  #start_date').val();
  var location                =$('#details_form  #location').val();

  
  if( company_name == '' )
  {
    $("#details_form #user_error").html( 'Please enter company_name.' ).show();
    return;
  }
  if( job_position == '' )
  {
    $("#details_form #user_error").html( 'Please enter job_position.' ).show();
    return;
  }
  
  if(start_date == '' )
  {
    $("#details_form #user_error").html( 'Please enter start_date.' ).show();
    return;
  }

  
  
if (location=='')
   {
    $("#details_form #user_error").html('Please enter location').show();
    return;
   }
  
   
  __user_details_info_form_xhr = $.ajax(
  {
    type: "POST"
    ,url: baseUrl + "/details"
    , data: {'company_name':company_name,'job_position' :job_position,'start_date' :start_date,'location':location}
    , dataType: 'json'
    , error: function () {
    },

    success: function(response) 
    {
      if (typeof response.error !== 'undefined' && response.error !== '') 
      {
        console.log("An error occurred: " + response.error);
      } 
      else 
      {

        console.log('details successful.');
        window.location.href = baseUrl +"dashboard";
      }
    }
  }); 
} 


